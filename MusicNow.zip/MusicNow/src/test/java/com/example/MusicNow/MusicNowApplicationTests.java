package com.example.MusicNow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicNowApplicationTests {

	@Test
	void contextLoads() {
	}

}
