package com.example.MusicNow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicNowApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicNowApplication.class, args);
	}

}
